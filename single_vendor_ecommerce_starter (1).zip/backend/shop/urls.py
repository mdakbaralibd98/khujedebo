from django.urls import path
from . import views
urlpatterns = [
    path("health/", views.health),
    path("products/", views.products),
    path("orders/", views.create_order),
    path("pay/wechat/<int:order_id>/", views.pay_wechat),
    path("pay/alipay/<int:order_id>/", views.pay_alipay),
]
