from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.utils.translation import gettext as _
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404
from .models import Product, Order, OrderItem, Payment
from .serializers import ProductSerializer, OrderSerializer
from .payments.wechat import create_jsapi_order as wx_create
from .payments.alipay import create_qr_order as ali_create
import uuid

@api_view(["GET"])
def health(_):
    return Response({"ok": True, "msg": _("Service running")})

@api_view(["GET"])
def products(_):
    qs = Product.objects.order_by("-created_at")[:100]
    return Response(ProductSerializer(qs, many=True).data)

@api_view(["POST"])
def create_order(request):
    user = User.objects.first()  # demo only; replace with auth user
    items = request.data.get("items", [])  # [{product_id, qty}]
    total = 0
    order = Order.objects.create(user=user, total_cents=0)
    for it in items:
        p = get_object_or_404(Product, pk=it["product_id"])
        qty = int(it.get("qty", 1))
        OrderItem.objects.create(order=order, product=p, quantity=qty, price_cents=p.price_cents)
        total += p.price_cents * qty
    order.total_cents = total
    order.save()
    return Response(OrderSerializer(order).data)

@api_view(["POST"])
def pay_wechat(request, order_id: int):
    order = get_object_or_404(Order, pk=order_id)
    out_trade_no = str(uuid.uuid4()).replace("-", "")[:32]
    pay = Payment.objects.create(provider="wechat", order=order, amount_cents=order.total_cents, out_trade_no=out_trade_no)
    prepay = wx_create(out_trade_no, f"Order#{order.id}", order.total_cents, payer_openid=request.data.get("openid",""))
    pay.raw = prepay
    pay.save()
    return Response({"prepay": prepay, "out_trade_no": out_trade_no})

@api_view(["POST"])
def pay_alipay(request, order_id: int):
    order = get_object_or_404(Order, pk=order_id)
    out_trade_no = str(uuid.uuid4()).replace("-", "")[:32]
    pay = Payment.objects.create(provider="alipay", order=order, amount_cents=order.total_cents, out_trade_no=out_trade_no)
    yuan = f"{order.total_cents/100:.2f}"
    result = ali_create(out_trade_no, f"Order#{order.id}", yuan)
    pay.raw = result
    pay.save()
    return Response({"alipay_result": str(result), "out_trade_no": out_trade_no})
