import requests, json
from django.conf import settings

def send_fcm_push(token: str, title: str, body: str, data: dict=None):
    # Legacy HTTP API for simplicity; migrate to HTTP v1 in production.
    headers = {
        "Authorization": f"key={settings.FCM_SERVER_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "to": token,
        "notification": {"title": title, "body": body},
        "data": data or {},
    }
    r = requests.post("https://fcm.googleapis.com/fcm/send", headers=headers, data=json.dumps(payload))
    return r.status_code, r.text
