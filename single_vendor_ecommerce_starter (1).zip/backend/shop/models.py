from django.db import models
from django.contrib.auth.models import User

class Category(models.Model):
    name = models.CharField(max_length=120)
    slug = models.SlugField(unique=True)
    def __str__(self): return self.name

class Product(models.Model):
    title = models.CharField(max_length=200)
    title_zh = models.CharField(max_length=200, blank=True, default="")
    slug = models.SlugField(unique=True)
    description = models.TextField(blank=True)
    description_zh = models.TextField(blank=True, default="")
    price_cents = models.PositiveIntegerField()
    stock = models.PositiveIntegerField(default=0)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="products")
    cover = models.URLField(blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self): return self.title

class Order(models.Model):
    STATUS = (
        ("pending","Pending"),
        ("paid","Paid"),
        ("shipped","Shipped"),
        ("completed","Completed"),
        ("canceled","Canceled"),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    total_cents = models.PositiveIntegerField()
    status = models.CharField(max_length=20, choices=STATUS, default="pending")
    created_at = models.DateTimeField(auto_now_add=True)

class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="items")
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    price_cents = models.PositiveIntegerField()

class Payment(models.Model):
    PROVIDERS = (("wechat","WeChat Pay"), ("alipay","Alipay"))
    provider = models.CharField(max_length=20, choices=PROVIDERS)
    order = models.OneToOneField(Order, on_delete=models.CASCADE, related_name="payment")
    amount_cents = models.PositiveIntegerField()
    out_trade_no = models.CharField(max_length=64, unique=True)
    transaction_id = models.CharField(max_length=128, blank=True, default="")
    success = models.BooleanField(default=False)
    raw = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
