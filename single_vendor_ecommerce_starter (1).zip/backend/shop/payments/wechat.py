import time, uuid
from django.conf import settings
from wechatpy.pay import WeChatPay

def create_jsapi_order(out_trade_no: str, description: str, total_cents: int, payer_openid: str):
    # Using WeChat v3 unified order (jsapi)
    # NOTE: You must configure merchant certs and keys in environment for production.
    wxpay = WeChatPay(appid=settings.WECHAT_APPID, mch_id=settings.WECHAT_MCH_ID, api_key=settings.WECHAT_API_KEY)
    data = {
        "body": description,
        "out_trade_no": out_trade_no,
        "total_fee": total_cents,
        "spbill_create_ip": "127.0.0.1",
        "notify_url": settings.WECHAT_NOTIFY_URL,
        "trade_type": "JSAPI",
        "openid": payer_openid,
    }
    res = wxpay.order.create(**data)
    # Return prepay info back to mini-program/app
    return res

def verify_notify(data: dict) -> bool:
    # TODO: verify signature with wechatpy (left simple for scaffold)
    return True
