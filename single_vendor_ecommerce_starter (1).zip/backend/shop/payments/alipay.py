import time
from alipay.aop.api.AlipayClientConfig import AlipayClientConfig
from alipay.aop.api.DefaultAlipayClient import DefaultAlipayClient
from alipay.aop.api.domain.AlipayTradePrecreateModel import AlipayTradePrecreateModel
from django.conf import settings

def _client():
    cfg = AlipayClientConfig()
    cfg.app_id = settings.ALIPAY_APPID
    cfg.app_private_key = settings.ALIPAY_PRIVATE_KEY
    cfg.alipay_public_key = settings.ALIPAY_PUBLIC_KEY
    return DefaultAlipayClient(alipay_client_config=cfg, logger=None)

def create_qr_order(out_trade_no: str, subject: str, total_yuan: str):
    # Precreate QR order for scan-to-pay
    client = _client()
    model = AlipayTradePrecreateModel()
    model.out_trade_no = out_trade_no
    model.total_amount = total_yuan
    model.subject = subject
    request = type("Req",(object,),{})()
    request.biz_model = model
    request.notify_url = settings.ALIPAY_NOTIFY_URL
    request.get_api_method_name = lambda : "alipay.trade.precreate"
    result = client.execute(request)
    return result  # contains 'qr_code'

def verify_notify(params: dict) -> bool:
    # TODO: verify signature properly with SDK
    return True
