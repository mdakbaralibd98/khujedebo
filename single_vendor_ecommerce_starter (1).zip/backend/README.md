# Django Backend
Single-vendor e-commerce API with Alipay & WeChat Pay stubs, bilingual (EN/简体中文), admin panel.

## Quickstart
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver 0.0.0.0:8000
```

- Admin: `/admin/`
- OpenAPI docs: `/api/docs/`
- Health: `/api/health/`
- Create order: `POST /api/orders/` body: `{"items":[{"product_id":1,"qty":1}]}`
- Pay WeChat (JSAPI): `POST /api/pay/wechat/{order_id}/` body: `{ "openid": "USER_OPENID" }`
- Pay Alipay (QR): `POST /api/pay/alipay/{order_id}/`

**Important:** Payment notify endpoints and signature verification are stubbed. Implement secure verification before going live.
