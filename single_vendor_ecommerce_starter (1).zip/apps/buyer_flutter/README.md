# Buyer Flutter App
Basic scaffold. Replace `YOUR_API_HOST` and implement UI/flows.
## Build AAB
```bash
flutter clean
flutter build appbundle --release
# Output: build/app/outputs/bundle/release/app-release.aab
```
## Push Notifications
- Add Firebase to Android app; configure `firebase_messaging` for FCM tokens and pass to backend.
