import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
void main() => runApp(App());

class App extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Buyer App',
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  List products = [];
  @override
  void initState() {
    super.initState();
    fetchProducts();
  }

  Future<void> fetchProducts() async {
    final res = await http.get(Uri.parse('https://YOUR_API_HOST/api/products/'));
    if (res.statusCode == 200) {
      setState(() => products = List.from((res.body as dynamic).toString().contains('[') ? [] : []));
      // Replace with proper JSON decode; kept minimal here.
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Buyer')),
      body: Center(child: Text('Connect to API and build buyer flows.')),
    );
  }
}
