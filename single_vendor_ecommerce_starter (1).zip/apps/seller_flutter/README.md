# Seller Flutter App
Manage products & orders; connect to admin APIs.
## Build AAB
```bash
flutter clean
flutter build appbundle --release
```
