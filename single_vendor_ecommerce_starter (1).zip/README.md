# Single-Vendor E‑Commerce (Python + WeChat/Alipay + Mini Program + Android)
**Languages:** 中文 / English  
**Backend:** Django + DRF (admin panel built-in)  
**Payments:** WeChat Pay (JSAPI), Alipay (QR precreate) — *scaffold stubs*  
**Clients:** WeChat Mini Program + Flutter Buyer/Seller (Android AAB)  
**Push:** Firebase Cloud Messaging (Android), template messages for Mini Program (add later)

## Setup Steps (Quick)
1) Backend: `cd backend && pip install -r requirements.txt && cp .env.example .env && python manage.py migrate && python manage.py createsuperuser && python manage.py runserver`
2) WeChat Mini Program: open `/wechat_mini_program` in WeChat DevTools, set API host, fill APPID.
3) Flutter Apps: open in Android Studio, set API host, connect Firebase for FCM, then `flutter build appbundle` to generate `.aab` for Google Play Console.
4) i18n: add Chinese translations with `django-admin makemessages -l zh_Hans` then `compilemessages`.

⚠️ **Security & Compliance**
- Implement server-side signature verification for both WeChat and Alipay notify callbacks before production.
- Serve backend via HTTPS and configure real merchant certificates/keys.
- Add proper authentication for buyer/seller roles (e.g., JWT) and RBAC for admin endpoints.
