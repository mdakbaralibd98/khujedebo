App({ onLaunch(){ console.log('App Launch') } })
