
Page({
  pay(){
    // Example: call your API to create WeChat JSAPI order and then invoke wx.requestPayment
    wx.request({
      url: 'https://YOUR_API_HOST/api/pay/wechat/ORDER_ID/',
      method: 'POST',
      data: { openid: 'USER_OPENID' },
      success: (res)=>{
        const p = res.data.prepay
        wx.requestPayment({
          timeStamp: p.timeStamp || '',
          nonceStr: p.nonceStr || '',
          package: p.package || '',
          signType: p.signType || 'MD5',
          paySign: p.paySign || '',
          success: ()=> wx.showToast({title:'支付成功'}),
          fail: ()=> wx.showToast({title:'支付失败',icon:'error'})
        })
      }
    })
  }
})
