
Page({
  data: { products: [] },
  onLoad(){
    wx.request({
      url: 'https://YOUR_API_HOST/api/products/',
      success: (res)=>{ this.setData({products: res.data}) }
    })
  },
  openProduct(e){
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: `/pages/product/product?id=${id}` })
  }
})
